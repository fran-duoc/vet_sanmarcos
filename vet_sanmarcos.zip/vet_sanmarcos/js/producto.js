const productos = {
    1: {
        nombre: "Alimento Perro Adulto",
        descripcion: "Alimento completo y balanceado formulado con proteínas de alta calidad e ingredientes naturales que facilitan una digestión saludable en perros adultos.",
        precio: "$45.990",
        imagen: "../img/badge.jpg"
    },

    2: {
        nombre: "Pipeta Antiparasitaria Gato",
        descripcion: "Tratamiento antiparasitario de aplicación tópica que elimina y previene pulgas, garrapatas y ácaros, brindando protección continua durante 30 días.",
        precio: "$11.500",
        imagen: "../img/pipeta.jpg"
    },

    3: {
        nombre: "Champú Hipoalergénico",
        descripcion: "Fórmula suave especialmente diseñada para perros y gatos con piel sensible o propensos a irritaciones, libre de parabenos y químicos agresivos.",
        precio: "$8.990",
        imagen: "../img/champu-mascota.jpg"
    },

    4: {
        nombre: "Set Dental Canino y Felino",
        descripcion: "Kit completo de higiene oral que remueve la acumulación de placa bacteriana, previene la formación de sarro y mantiene un aliento fresco.",
        precio: "$3.490",
        imagen: "../img/set-dental.jpg"
    },

    5: {
        nombre: "Arena Sanitaria Aglomerante",
        descripcion: "Arena de alta absorción que forma aglomerados firmes para una limpieza rápida y sencilla, neutralizando eficazmente los malos olores del arenero.",
        precio: "$13.990",
        imagen: "../img/arena-gato.jpg"
    },

    6: {
        nombre: "Suplemento Multivitamínico",
        descripcion: "Suplemento nutricional con vitaminas y minerales esenciales diseñado para fortalecer el sistema inmune, la salud articular y mantener un pelaje brillante.",
        precio: "$14.990",
        imagen: "../img/multivitaminico.jpg"
    },

    7: {
        nombre: "Juguete para Mascota Tucán",
        descripcion: "Juguete interactivo de textura resistente con sonido integrado, ideal para estimular el instinto de juego, el ejercicio físico y reducir el estrés.",
        precio: "$13.990",
        imagen: "../img/tucan.jpg"
    },

    8: {
        nombre: "Alimento para Conejo Purina",
        descripcion: "Mezcla nutritiva rica en fibra cruda y nutrientes esenciales, formulada especialmente para favorecer el desgaste dental y una óptima digestión en conejos.",
        precio: "$27.990",
        imagen: "../img/comida_conejo.jpg"
    }
};

let url = window.location.search;
let parametros = new URLSearchParams(url);
let id = parametros.get("id");

let producto = productos[id];

if (producto) {
    document.getElementById("nombre-producto").innerText = producto.nombre;
    document.getElementById("descripcion-producto").innerText = producto.descripcion;
    document.getElementById("precio-producto").innerText = "Precio: " + producto.precio;
    document.getElementById("imagen-producto").src = producto.imagen;
} else {
    document.getElementById("nombre-producto").innerText = "Producto no encontrado";
}