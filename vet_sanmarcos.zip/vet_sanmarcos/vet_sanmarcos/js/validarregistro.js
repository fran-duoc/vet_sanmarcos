function validarRegistro() {
    let nombre = document.getElementById("nombre");
    let rut = document.getElementById("rut");
    let correo = document.getElementById("correo");
    let telefono = document.getElementById("telefono");
    let fenac = document.getElementById("fenac");
    let pass1 = document.getElementById("pass");
    let pass2 = document.getElementById("pass-confirm");

    if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(nombre.value)) {
        alert("El nombre debe contener solo letras.");
        nombre.focus();
        return false;
    }

    if (!/^[0-9]{1,2}\.[0-9]{3}\.[0-9]{3}\-[0-9kK]$/.test(rut.value)) {
        alert("El RUT debe tener el formato 22.123.456-7");
        rut.focus();
        return false;
    }

    if (!/^[a-zA-Z0-9._%+-]+@(duocuc|outlook|gmail)\.(cl|com)$/.test(correo.value)) {
        alert("Solo se aceptan correos terminados en @gmail.com, @duocuc.cl o @outlook.com");
        correo.focus();
        return false;
    }

    if (!/^\+569[0-9]{8}$/.test(telefono.value)) {
        alert("El teléfono debe contener +569 seguido de 8 números.");
        telefono.focus();
        return false;
    }

    if (!/^(19[0-9]{2}|200[0-8])\-(0[1-9]|1[0-2])\-(0[1-9]|[12][0-9]|3[01])$/.test(fenac.value)) {
        alert("Debes ser mayor de 18 años.");
        fenac.focus();
        return false;
    }

    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(pass1.value)) {
        alert("La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número.");
        pass1.focus();
        return false;
    }

    if (pass1.value !== pass2.value) {
        alert("Las contraseñas no coinciden.");
        pass2.focus();
        return false;
    }

    localStorage.setItem("correoGuardado", correo.value);
    localStorage.setItem("contrasenaGuardada", pass1.value);

    alert("¡Registro exitoso! Redirigiendo al inicio de sesión...");
    window.location.href = "login.html";
    return false;
}