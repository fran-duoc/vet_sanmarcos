let formulario = document.getElementById("formulario-login");
let correo = document.getElementById("correo");
let contrasena = document.getElementById("contrasena");

formulario.addEventListener("submit", function(event){
    event.preventDefault();

    if(!/^[^\s@]+@(duocuc\.cl|gmail\.com|outlook\.com)$/.test(correo.value)){
        alert("Solo se acepta correos terminados en @gmail.com, @duocuc.cl o @outlook.com");
        correo.focus();
        return;
    }   

    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(contrasena.value)) {
        alert("La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número.");
        contrasena.focus();
        return;
    }

    let correoGuardado = localStorage.getItem("correoGuardado");
    let contrasenaGuardada = localStorage.getItem("contrasenaGuardada");

    if (!correoGuardado || !contrasenaGuardada) {
        alert("No hay ningún usuario registrado. Por favor regístrate primero.");
        return;
    }

    if (correo.value === correoGuardado && contrasena.value === contrasenaGuardada) {
        alert("¡Inicio de sesión exitoso!");
        // Redirección a la página principal (misma carpeta)
        window.location.href = "index.html"; 
    } else {
        alert("El correo o la contraseña son incorrectos.");
        contrasena.focus();
    }
});